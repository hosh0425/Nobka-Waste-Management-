package com.example.hossein.myapplication;

import android.app.ProgressDialog;
import android.app.TaskStackBuilder;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.nfc.Tag;
import android.os.SystemClock;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.UUID;

public class BluetoothConnectionService {
    private static final String TAG = "BluetoothChatService";
    private static final String appName="myapp";

    private static final UUID MY_UUID_INSECURE =
            UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");

    private String input_data;
    private int input_data_size;

    private final BluetoothAdapter mBluetoothAdapter;
    Context mcontext;

    private AcceptThread mInsecureAcceptThread;
    private ConnectThread mConnectThread;
    private BluetoothDevice mmDevice;
    private UUID deviceUUID;
    ProgressDialog mpProgressDialog;

    private ConnectedThread mConnectedThread;

    int value;


    public BluetoothConnectionService( Context context) {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
         mcontext = context;
        start();

    }



    private class AcceptThread extends Thread {
        private final BluetoothServerSocket mmServerSocket;

        public AcceptThread() {
            BluetoothServerSocket tmp=null;

            try{
                tmp=mBluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(appName,MY_UUID_INSECURE);
                Log.d(TAG,"AccepThread"+MY_UUID_INSECURE);

            }catch (IOException e){
                Log.e(TAG,"run Accept thread running"+e.getMessage());

            }

            mmServerSocket=tmp;
        }

        public void run(){
            Log.d(TAG,"run Accept thread running");
            BluetoothSocket socket=null;

            try{
                //this is a blocking calll and will only return on a succesfull connection or exception
                socket=mmServerSocket.accept();
                Log.d(TAG,"connection successfull");

            }catch (IOException e){
                Log.e(TAG,"run Accept thread running"+e.getMessage());

            }

            if(socket!=null)
                connected(socket,mmDevice);

            Log.i(TAG,"End except thread ");
        }


        public void cancel() {
            Log.d(TAG, "canceling accept thread");
            try {
                mmServerSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "canceling accept thread" + e.getMessage());
            }
        }
    }

    private class ConnectThread extends Thread{
        private BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device,UUID uuid) {
            //this.mmSocket = mmSocket;
            Log.d(TAG,"connect thread started");
            mmDevice=device;
            deviceUUID=uuid;
        }

        public void run(){
            BluetoothSocket temp=null;
            Log.d(TAG,"tun connect thread");
            try {
                temp=mmDevice.createRfcommSocketToServiceRecord(deviceUUID);

            } catch (IOException e) {
                Log.e(TAG,"connect thread couldnot create insecureRFcommsocket");
            }

            mmSocket=temp;
            mBluetoothAdapter.cancelDiscovery();

            try {
                mmSocket.connect();
            } catch (IOException e) {
                try {
                    mmSocket.close();
                }catch (IOException e1){
                    Log.e(TAG,"unable to close connection in socket");
                }
            }


            connected(mmSocket,mmDevice);

        }



        public void cancel() {
            Log.d(TAG, "canceling accept thread");
            try {
                mmSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "canceling accept thread" + e.getMessage());
            }
        }

    }

    public synchronized void start() {
        Log.d(TAG, "start");

        // Cancel any thread attempting to make a connection
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }

        if (mInsecureAcceptThread == null) {
            mInsecureAcceptThread = new AcceptThread();
            mInsecureAcceptThread.start();
        }
    }

    public void startClient(BluetoothDevice device,UUID uuid){
        Log.d(TAG,"start client started");
        mpProgressDialog=mpProgressDialog.show(mcontext,"connecting to bluetooth","please wait ...",true);

        mConnectThread=new ConnectThread(device,uuid);
        mConnectThread.start();
    }

    private class ConnectedThread extends Thread{
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        public ConnectedThread(BluetoothSocket socket){
            Log.d(TAG,"connected thread");
            mmSocket=socket;
            InputStream tempIn=null;
            OutputStream tempOut=null;

            try {
                mpProgressDialog.dismiss();
            }catch (NullPointerException e){

            }

            try {
                tempIn=mmSocket.getInputStream();
                tempOut=mmSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            mmInStream=tempIn;
            mmOutStream=tempOut;

        }

        public void run(){
            byte[] buffer=new byte[10];

            int bytes;
            int available=1;
            value=0;

            while (true){
                try{
                    available=mmInStream.available();
                }catch (IOException e){
                    Log.e(TAG, "error get available bytes" + e.getMessage());

                }
                if(available==3) {
                    try {

                        bytes = mmInStream.read(buffer);
                        value=readInt(buffer);
                        input_data_size = bytes;
                        //if(buffer[0]==42 && buffer[bytes]==35) {
                        String incomingMessage = new String(buffer, 0, bytes);

                        //}
                        input_data = incomingMessage;
                        Log.d(TAG, "Input stream: " + incomingMessage);//
                    } catch (IOException e) {

                        Log.e(TAG, "error reading in stream" + e.getMessage());
                        break;
                    }
                }
                else {
                    SystemClock.sleep(100);
                }

            }
        }




        public void write(byte[] bytes){
            String text=new String(bytes, Charset.defaultCharset());
            Log.d(TAG,"Out stream: "+text);

            try {
                mmOutStream.write(bytes);
            } catch (IOException e) {
                Log.e(TAG,"error writing out stream"+e.getMessage());
            }
        }
        public void cancel(){
            try {
                mmSocket.close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private void connected(BluetoothSocket mmSocket, BluetoothDevice mmDevice) {
        Log.d(TAG,"connected: starting");

        //start thread to manage the conection and perform transition
        mConnectedThread=new ConnectedThread(mmSocket);
        mConnectedThread.start();
    }

    public void write(byte[] out){
        ConnectedThread r;
        Log.d(TAG,"write: Write called");
        mConnectedThread.write(out);
    }

    public int readInt(byte[] b) {
        if (b != null) {
            int value = 0;
            value += ((b[2]-48) *1);
            value += ((b[1]-48) *10);
            value += ((b[0]-48) *100);
            return value;
        }
        return -1;
    }


    public int read(){
        Log.d(TAG, "Input stream, Timer event: " + value);//

        //if(input_data_size!=4)
         //   input_data="bad data";

        return value;
    }
}



































