package com.example.hossein.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothAdapter;



public class DiscoverDevices extends AppCompatActivity {
    public ArrayList<BluetoothDevice>mBTDevices ;

    ListView listView;
    public DeviceListAdapter mDeviceListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover_devices);
        Intent intent=getIntent();
        mBTDevices=(ArrayList<BluetoothDevice>)intent.getSerializableExtra("key");
        listView=findViewById(R.id.listView);
        Toast.makeText(this,"extra: "+ mBTDevices.get(1),Toast.LENGTH_SHORT).show();
        refresListView();
    }

    private void refresListView() {
        mDeviceListAdapter = new DeviceListAdapter(this, R.layout.device_adapter_view, mBTDevices);
        listView.setAdapter(mDeviceListAdapter);


//        BluetoothAdapter<String> adapter=new BluetoothAdapter(this,android.R.layout.simple_list_item_1,item);
//        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //parent.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(),"extra: "+parent.getItemAtPosition(position) ,Toast.LENGTH_SHORT).show();

                Intent resultIntent = new Intent();
                resultIntent.putExtra("device", position);
                setResult(RESULT_OK,resultIntent);
                finish();
            }
        });
    }
}
