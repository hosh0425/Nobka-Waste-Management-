package com.example.hossein.myapplication;

import android.Manifest;
import android.app.ActionBar;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    private static final String TAG = "MainActivity";
    private static final UUID MY_UUID_INSECURE =//UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");


    BluetoothAdapter mBluetoothAdapter;
    BluetoothConnectionService mBluetoothConnection;
    BluetoothDevice mBTDevice;


    TextView receiveTextView;

    public ArrayList<BluetoothDevice> mBTDevices = new ArrayList<>();
    public DeviceListAdapter mDeviceListAdapter;

    ListView lvNewDevices;

    ImageView nobkaIv;
    ImageView zeroIv,firstIv,secondIv,thirdIv,fourthIv;




    // Create a BroadcastReceiver for ACTION_FOUND
    private final BroadcastReceiver mBroadcastReceiver1 = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // When discovery finds a device
            if (action.equals(mBluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, mBluetoothAdapter.ERROR);

                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        Log.d(TAG, "onReceive: STATE OFF");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.d(TAG, "mBroadcastReceiver1: STATE TURNING OFF");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.d(TAG, "mBroadcastReceiver1: STATE ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.d(TAG, "mBroadcastReceiver1: STATE TURNING ON");
                        break;
                }
            }
        }
    };

    /**
     * Broadcast Receiver for changes made to bluetooth states such as:
     * 1) Discoverability mode on/off or expire.
     */
    private final BroadcastReceiver mBroadcastReceiver2 = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED)) {

                int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);

                switch (mode) {
                    //Device is in Discoverable Mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(TAG, "mBroadcastReceiver2: Discoverability Enabled.");
                        break;
                    //Device not in discoverable mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(TAG, "mBroadcastReceiver2: Discoverability Disabled. Able to receive connections.");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(TAG, "mBroadcastReceiver2: Discoverability Disabled. Not able to receive connections.");
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        Log.d(TAG, "mBroadcastReceiver2: Connecting....");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(TAG, "mBroadcastReceiver2: Connected.");
                        break;
                }

            }
        }
    };




    /**
     * Broadcast Receiver for listing devices that are not yet paired
     * -Executed by btnDiscover() method.
     */
    private BroadcastReceiver mBroadcastReceiver3 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "onReceive: ACTION FOUND.");

            if (action.equals(BluetoothDevice.ACTION_FOUND)){
                BluetoothDevice device = intent.getParcelableExtra (BluetoothDevice.EXTRA_DEVICE);
                mBTDevices.add(device);
                Log.d(TAG, "onReceive: " + device.getName() + ": " + device.getAddress());
                mDeviceListAdapter = new DeviceListAdapter(context, R.layout.device_adapter_view, mBTDevices);
                //lvNewDevices.setAdapter(mDeviceListAdapter);
            }
        }
    };

    /**
     * Broadcast Receiver that detects bond state changes (Pairing status changes)
     */
    private final BroadcastReceiver mBroadcastReceiver4 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if(action.equals(BluetoothDevice.ACTION_BOND_STATE_CHANGED)){
                BluetoothDevice mDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                //3 cases:
                //case1: bonded already
                if (mDevice.getBondState() == BluetoothDevice.BOND_BONDED){
                    Log.d(TAG, "BroadcastReceiver: BOND_BONDED.");
                    mBTDevice=mDevice;
                }
                //case2: creating a bone
                if (mDevice.getBondState() == BluetoothDevice.BOND_BONDING) {
                    Log.d(TAG, "BroadcastReceiver: BOND_BONDING.");
                }
                //case3: breaking a bond
                if (mDevice.getBondState() == BluetoothDevice.BOND_NONE) {
                    Log.d(TAG, "BroadcastReceiver: BOND_NONE.");
                }
            }
        }
    };



    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy: called.");
        super.onDestroy();
        unregisterReceiver(mBroadcastReceiver1);
        unregisterReceiver(mBroadcastReceiver2);
        unregisterReceiver(mBroadcastReceiver3);
        unregisterReceiver(mBroadcastReceiver4);
        //mBluetoothAdapter.cancelDiscovery();
    }


    /*
     *
     * timer
     *
     *
     */
    long starttime = 0;
    Timer timer ;
    int allowTimerHandlerReadInputData =0;
    int delete_prev_image=0;

    final Handler h = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            long millis = System.currentTimeMillis() - starttime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds     = seconds % 60;
            //BluetoothConnectionService mBluetoothConnectionTemp;
            //mBluetoothConnectionTemp=mBluetoothConnection;
           /* String inputData;
            try{
                inputData = mBluetoothConnection.read();
                receiveTextView.setText(inputData);
            }catch (NullPointerException e){

            }*/

            if(allowTimerHandlerReadInputData ==1) {
                setInput();
                delete_prev_image++;
                if(delete_prev_image==10)
                    nobkaIv.animate().alpha(0).setDuration(500);

                if(delete_prev_image==1100)
                    delete_prev_image=11;
            }
            else
                receiveTextView.setText(String.format("%d:%02d", minutes, seconds));


            return false;
        }
    });
    //tells handler to send a message
    class firstTask extends TimerTask {

        @Override
        public void run() {

            h.sendEmptyMessage(0);
        }
    };
    /*
     *
     * end timer
     *
     *
     */

    /*
     *
     * find nobka bluetooth timer
     *
     *
     */
    long starttime2 = 0;
    Timer timer_nobka;
    int finde_nobka = 0;


    final Handler nobka_handler = new Handler(new Handler.Callback() {

        @Override
        public boolean handleMessage(Message msg) {
            // Toast.makeText(getApplicationContext(), "connecting to Nobka", Toast.LENGTH_SHORT).show();

            if (finde_nobka == 0) {
                for (int i = 0; i <mBTDevices.size(); i++)
                    if (mBTDevices.get(i).getName().equals("NOBKA")) {//
                        mBTDevices.get(i).createBond();
                        mBTDevice = mBTDevices.get(i);
                        mBluetoothConnection = new BluetoothConnectionService(MainActivity.this);
                        Toast.makeText(getApplicationContext(), "connecting to Nobka", Toast.LENGTH_SHORT).show();
                        finde_nobka = 1;
                        timer_nobka.cancel();
                        startConnection();
                    }
            }
            return false;
        }
    });

    //tells handler to send a message
    class firstTask_nobka extends TimerTask {

        @Override
        public void run() {

            nobka_handler.sendEmptyMessage(0);
        }
    }

    ;
    /*
     *
     * end read input data timer
     *
     *
     */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
       // setTheme(R.style.AppTheme);
       // SystemClock.sleep(2000);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(100,100,100));



        lvNewDevices = (ListView) findViewById(R.id.lvNewDevices);
        mBTDevices = new ArrayList<>();

        receiveTextView =findViewById(R.id.receiveTextView);
        zeroIv=findViewById(R.id.trash_zero);
        firstIv=findViewById(R.id.trash_first);
        secondIv=findViewById(R.id.trash_sec);
        thirdIv=findViewById(R.id.trsh_third);
        fourthIv=findViewById(R.id.trash_fourth);
        nobkaIv=findViewById(R.id.nobka);



        //Broadcasts when bond state changes (ie:pairing)
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(mBroadcastReceiver4, filter);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        lvNewDevices.setOnItemClickListener(MainActivity.this);



       //getSupportActionBar().setIcon(R.drawable.nobka2);


        starttime = System.currentTimeMillis();
        timer = new Timer();
        timer.schedule(new firstTask(), 1000,500);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu_main, menu);

        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.onOffItem) {
            Log.d(TAG, "onClick: enabling/disabling bluetooth.");
            enableDisableBT();

        } else if (item.getItemId() == R.id.discoverItem) {
            Log.d(TAG, "btnDiscover: Looking for unpaired devices.");

            if (mBluetoothAdapter.isDiscovering()) {
                mBluetoothAdapter.cancelDiscovery();
                Log.d(TAG, "btnDiscover: Canceling discovery.");

                //check BT permissions in manifest
                checkBTPermissions();

                mBluetoothAdapter.startDiscovery();
                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
            }
            if (!mBluetoothAdapter.isDiscovering()) {

                //check BT permissions in manifest
                checkBTPermissions();

                mBluetoothAdapter.startDiscovery();
                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                //discoverDevicesIntent.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);

                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
            }
            starttime2 = System.currentTimeMillis();
            timer_nobka = new Timer();
            timer_nobka.schedule(new firstTask_nobka(), 3000, 500);
            /*
            if(mBTDevices.size()>=1) {
                Intent myIntent = new Intent(this, DiscoverDevices.class);
                myIntent.putExtra("key", (Serializable) mBTDevices);
                startActivityForResult(myIntent, 1);
            }
            */
        }


        return super.onOptionsItemSelected(item);
    }


    int value;
    ByteBuffer wrapped;
    public void setInput() {
        //String inputData = mBluetoothConnection.read();
        value=0;
        value=mBluetoothConnection.read();

        if (value != 0) {

            //receiveTextView.setText("Distance: " + value+"cm");

            if (value > 22 && value < 120) {
                receiveTextView.setText("Distance: " + value+"cm");
                if(value<35){
                    //receiveTextView.setText(" zero " + value);
                    zeroIv.animate().alpha(0).setDuration(500);
                    firstIv.animate().alpha(0).setDuration(500);
                    secondIv.animate().alpha(0).setDuration(500);
                    thirdIv.animate().alpha(0).setDuration(500);
                    fourthIv.animate().alpha(1).setDuration(500);
                }
                else if (value > 40 && value <55) {
                    //receiveTextView.setText(" first " + value);
                    zeroIv.animate().alpha(0).setDuration(500);
                    firstIv.animate().alpha(0).setDuration(500);
                    secondIv.animate().alpha(0).setDuration(500);
                    thirdIv.animate().alpha(1).setDuration(500);
                    fourthIv.animate().alpha(0).setDuration(500);
                }
                else if(value>60 && value<80) {
                    //receiveTextView.setText(" sec " + value);
                    zeroIv.animate().alpha(0).setDuration(500);
                    firstIv.animate().alpha(0).setDuration(500);
                    secondIv.animate().alpha(1).setDuration(500);
                    thirdIv.animate().alpha(0).setDuration(500);
                    fourthIv.animate().alpha(0).setDuration(500);
                }
                else if(value>85 && value<100){
                    //receiveTextView.setText(" third " + value);

                    zeroIv.animate().alpha(0).setDuration(500);
                    firstIv.animate().alpha(1).setDuration(500);
                    secondIv.animate().alpha(0).setDuration(500);
                    thirdIv.animate().alpha(0).setDuration(500);
                    fourthIv.animate().alpha(0).setDuration(500);
                }
                else if(value>105){
                    //receiveTextView.setText(" fourth " + value);

                    zeroIv.animate().alpha(1).setDuration(500);
                    firstIv.animate().alpha(0).setDuration(500);
                    secondIv.animate().alpha(0).setDuration(500);
                    thirdIv.animate().alpha(0).setDuration(500);
                    fourthIv.animate().alpha(0).setDuration(500);
                }
            }
            else
                receiveTextView.setText("Out of range");

        }



    }



    public void startConnection(){
        startBTConnection(mBTDevice,MY_UUID_INSECURE);
        starttime = System.currentTimeMillis();
        timer = new Timer();
        timer.schedule(new firstTask(), 1000, 500);
        allowTimerHandlerReadInputData=1;
    }

    public void startBTConnection(BluetoothDevice device,UUID uuid){
        Log.d(TAG,"start btn connection");
        mBluetoothConnection.startClient(device,uuid);

    }



    public void enableDisableBT(){
        if(mBluetoothAdapter == null){
            Log.d(TAG, "enableDisableBT: Does not have BT capabilities.");
        }
        if(!mBluetoothAdapter.isEnabled()){
            Log.d(TAG, "enableDisableBT: enabling BT.");
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBTIntent);

            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(mBroadcastReceiver1, BTIntent);
        }
        if(mBluetoothAdapter.isEnabled()){
            Log.d(TAG, "enableDisableBT: disabling BT.");
            mBluetoothAdapter.disable();

            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(mBroadcastReceiver1, BTIntent);
        }

    }


    public void btnEnableDisable_Discoverable(View view) {
        Log.d(TAG, "btnEnableDisable_Discoverable: Making device discoverable for 300 seconds.");

        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(discoverableIntent);

        IntentFilter intentFilter = new IntentFilter(mBluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        registerReceiver(mBroadcastReceiver2,intentFilter);

    }

    /*
    public void btnDiscover(View view) {
        Log.d(TAG, "btnDiscover: Looking for unpaired devices.");

        if(mBluetoothAdapter.isDiscovering()){
            mBluetoothAdapter.cancelDiscovery();
            Log.d(TAG, "btnDiscover: Canceling discovery.");

            //check BT permissions in manifest
            checkBTPermissions();

            mBluetoothAdapter.startDiscovery();
            IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
        }
        if(!mBluetoothAdapter.isDiscovering()){

            //check BT permissions in manifest
            checkBTPermissions();

            mBluetoothAdapter.startDiscovery();
            IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
        }
    }
    */

    /**
     * This method is required for all devices running API23+
     * Android must programmatically check the permissions for bluetooth. Putting the proper permissions
     * in the manifest is not enough.
     *
     * NOTE: This will only execute on versions > LOLLIPOP because it is not needed otherwise.
     */
    private void checkBTPermissions() {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            int permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != 0) {

                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1001); //Any number
            }
        }else{
            Log.d(TAG, "checkBTPermissions: No need to check permissions. SDK version < LOLLIPOP.");
        }
    }

//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event){
//        if((keyCode==KeyEvent.KEYCODE_BACK)){
//            finish();
//        }
//        return super.onKeyDown(keyCode,event);
//    }
//    @Override
//    public void onBackPressed(){
//        super.onBackPressed();
//        this.finish();
//    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//        //first cancel discovery because its very memory intensive.
//        mBluetoothAdapter.cancelDiscovery();
//
//        Log.d(TAG, "onItemClick: You Clicked on a device.");
//        String deviceName = mBTDevices.get(i).getName();
//        String deviceAddress = mBTDevices.get(i).getAddress();
//        Toast.makeText(getApplicationContext(),"connecting to: "+ deviceName,Toast.LENGTH_SHORT).show();
//
//        Log.d(TAG, "onItemClick: deviceName = " + deviceName);
//        Log.d(TAG, "onItemClick: deviceAddress = " + deviceAddress);
//
//        //create the bond.
//        //NOTE: Requires API 17+? I think this is JellyBean
//        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN_MR2){
//            Log.d(TAG, "Trying to pair with " + deviceName);
//            mBTDevices.get(i).createBond();
//            mBTDevice=mBTDevices.get(i);
//            mBluetoothConnection=new BluetoothConnectionService(MainActivity.this);
//            allowTimerHandlerReadInputData =1;
//        }
    }
}

/*
package com.example.hossein.myapplication;


*/